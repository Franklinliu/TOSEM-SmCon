mythril.laser.plugin.plugins package
====================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   mythril.laser.plugin.plugins.coverage
   mythril.laser.plugin.plugins.summary_backup

Submodules
----------

mythril.laser.plugin.plugins.benchmark module
---------------------------------------------

.. automodule:: mythril.laser.plugin.plugins.benchmark
   :members:
   :undoc-members:
   :show-inheritance:

mythril.laser.plugin.plugins.call\_depth\_limiter module
--------------------------------------------------------

.. automodule:: mythril.laser.plugin.plugins.call_depth_limiter
   :members:
   :undoc-members:
   :show-inheritance:

mythril.laser.plugin.plugins.dependency\_pruner module
------------------------------------------------------

.. automodule:: mythril.laser.plugin.plugins.dependency_pruner
   :members:
   :undoc-members:
   :show-inheritance:

mythril.laser.plugin.plugins.instruction\_profiler module
---------------------------------------------------------

.. automodule:: mythril.laser.plugin.plugins.instruction_profiler
   :members:
   :undoc-members:
   :show-inheritance:

mythril.laser.plugin.plugins.mutation\_pruner module
----------------------------------------------------

.. automodule:: mythril.laser.plugin.plugins.mutation_pruner
   :members:
   :undoc-members:
   :show-inheritance:

mythril.laser.plugin.plugins.plugin\_annotations module
-------------------------------------------------------

.. automodule:: mythril.laser.plugin.plugins.plugin_annotations
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: mythril.laser.plugin.plugins
   :members:
   :undoc-members:
   :show-inheritance:
