Welcome to Mythril's documentation!
===========================================

.. toctree::
   :maxdepth: 1
   :caption: Table of Contents:

   about
   installation
   tutorial
   security-analysis
   analysis-modules
   mythril


Indices and Tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

