Analysis Modules
================

Mythril's detection capabilities are written in modules in the `/analysis/module/modules <https://github.com/ConsenSys/mythril/tree/master/mythril/analysis/module/modules>`_ directory.


.. toctree::
   :maxdepth: 2

   module-list.rst
   create-module.rst
