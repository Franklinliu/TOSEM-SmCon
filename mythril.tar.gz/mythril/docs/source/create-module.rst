Creating a Module
=================

Create a module in the :code:`analysis/modules` directory, and create an instance of a class that inherits :code:`DetectionModule` named :code:`detector`. Take a look at the `suicide module <https://github.com/Consensys/mythril/blob/develop/mythril/analysis/module/modules/suicide.py>`_ as an example.
