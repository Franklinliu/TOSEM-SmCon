from typing import List
from mythril.support.support_utils import Singleton


class Args(object, metaclass=Singleton):
    """
    This module helps in preventing args being sent through multiple of classes to reach
    any analysis/laser module
    """

    def __init__(self):
        self.solver_timeout = 10000
        self.pruning_factor = None
        self.unconstrained_storage = False
        self.parallel_solving = False
        self.call_depth_limit = 3
        self.disable_iprof = False
        self.solver_log = None
        self.transaction_sequences: List[List[str]] = None
        self.use_integer_module = True
        self.use_issue_annotations = False
        self.solc_args = None
        self.disable_coverage_strategy = False
        self.disable_mutation_pruner = False
        self.incremental_txs = True
        self.enable_summaries = False
        self.enable_state_merge = False


args = Args()
