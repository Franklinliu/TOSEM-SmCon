"""This file contains the current Mythril version.

This file is suitable for sourcing inside POSIX shell, e.g. bash as well
as for importing into Python.
"""

__version__ = "v0.24.8"
