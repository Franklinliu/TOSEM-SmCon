from mythril.laser.plugin.plugins.coverage.coverage_plugin import (
    InstructionCoveragePlugin,
)
