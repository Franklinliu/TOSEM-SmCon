#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
import mythril.interfaces.cli

if __name__ == "__main__":
    mythril.interfaces.cli.main()
