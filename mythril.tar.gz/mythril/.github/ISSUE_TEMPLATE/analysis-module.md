---
name: Analysis module
about: Create an analysis module feature request

---

<!-- Please remove any of the optional sections if they are not applicable. -->

## Description

<!-- Add a description of an vulnerability that should be
detected by a Mythril analysis module. -->

## Tests

<!-- This section is optional.

Suggest how to test the feature, if it is not obvious. This might
require certain Solidity source, bytecode, or a Truffle project. You
can also provide links to existing code. -->

## Implementation details

<!-- This section is optional.

If you have thoughts about how to implement the analysis, add
this here. -->

## Links

<!-- This section is optional.

Add links describing the issue or pointing to resources that can help
in implementing the analysis.

Thanks for helping! -->
