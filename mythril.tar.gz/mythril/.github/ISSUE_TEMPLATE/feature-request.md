---
name: Feature Request
about: Tell us about a new feature that would make Mythril better

---

## Description

<!-- Give a short description of the feature. -->

## Background

<! -- Replace this text with any additional background for the
feature, for example: user scenarios, or the value of the feature. -->

## Tests

<!-- This section is optional.

Suggestion how to test the feature, if it is not obvious.

This might require certain Solidity source, bytecode, or a Truffle
project. You can also provide links to existing code.

Thanks for helping!

-->
