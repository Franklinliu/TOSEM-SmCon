Files found in this directory are taken from https://github.com/ethereum/tests, released under the 
license LICENSE in the same directory as this file.

All credit goes to the awesome people that made this!
