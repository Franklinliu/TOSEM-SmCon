# Note

## contract 1
0x38c2af432D0Aa8eE1e1ee0A76d5Bb1469b621812
