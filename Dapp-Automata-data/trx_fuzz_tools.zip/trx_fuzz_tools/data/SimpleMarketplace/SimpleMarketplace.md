# Note

## contract 1

contract address 0x299C996303a90c826B777175E6480a722e54Bdd8

InstanceOwner 0x35fA38D6e01F98B5e9f7672b0294177388BB381e



MakeOffer



## contract 2

contract address 0xF1395b9B18941c8A1514f47d35389Dd4d807714d

InstanceOwner 0x20E646cA24A51E324aD07644245a07fEed0426C2

MakeOffer -> Accept

## contract 3

contract address 0xBAD0D91BCB25a10F14dc8753eb31046bb2daa218

InstanceOwner 0x606Ec1CA1C986462C52bDE7Bb7F694DB08c1Af72

MakeOffer -> Reject



## contract 4

contract address 0x74C142d69252d7Cbc34f94B3948A899a2D78fd28

InstanceOwner 0x20E646cA24A51E324aD07644245a07fEed0426C2

MakeOffer -> Reject -> MakeOffer -> Reject -> Make offer 



## contact 5

contract Address 0xc06976C98b5187CD542a58569a52ad50ca833516

InstanceOwner 0x20E646cA24A51E324aD07644245a07fEed0426C2

M -> R -> M -> A