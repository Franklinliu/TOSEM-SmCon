# Note

## contract 1

contract address 0x7ad8d092734056EAA42e54471BF7b1b089F85E4e

SupplyChainOwner 0x20E646cA24A51E324aD07644245a07fEed0426C2

SupplyChainObserver 0x0167a993B82feF5033645b2Bc345325646B3FDEd



Complete



## contract 2

contract address 0x636D7121f77c0C82A4F6c5AB8773647bb8eD98fE

SupplyChainOwner 0x20E646cA24A51E324aD07644245a07fEed0426C2

SupplyChainObserver 0x20E646cA24A51E324aD07644245a07fEed0426C2



![image-20230822165659896](/Users/catblue/Library/Application Support/typora-user-images/image-20230822165659896.png)

## contract 3

contract address 0xeE5bC7912fFAA898aE0F1b20Aded74F1B0C59F41

SupplyChainOwner 0x64DFEAe370C5174B3595dBb1DC04651595b7Da37

SupplyChainObserver 0x64DFEAe370C5174B3595dBb1DC04651595b7Da37



transit-> completed

## contract 4

contract address 0x05fC9E6f83cd7a18f8b5Ce53A190e34F0e8BC2E8

SupplyChainOwner 0x35fA38D6e01F98B5e9f7672b0294177388BB381e

SupplyChainObserver 0x20E646cA24A51E324aD07644245a07fEed0426C2



transit



## contract	 5

contract address 0xb2b6214894D0FDd695342D21E54bb46eC7e90778

SupplyChainOwner 0x35fA38D6e01F98B5e9f7672b0294177388BB381e

SupplyChainObserver 0x20E646cA24A51E324aD07644245a07fEed0426C2



transit -> transit -> transit -> transit