# Note

## contract 1

contract address 0x125cBEc58e9B6E894C77391817B41aDaCFa835C8

Manufacturer address 0x666474a318918123e27b9d6f1283528C88f97827



ComputeTotal 